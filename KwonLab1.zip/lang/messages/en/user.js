//string messages
const messages = {
    error: {
      correctOrder: 'Correct error',
      incorrectOrder: 'Wrong error!',
      condition: 'condition error',
    },
    save: "save completed",
};

  